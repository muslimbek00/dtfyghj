from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'), 
    path('product/<int:product_id>/', views.product_detail, name='product_detail'),
    path('products/filter/', views.product_filter, name='filter_products'),
]
